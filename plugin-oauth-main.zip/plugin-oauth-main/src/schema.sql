CREATE TABLE IF NOT EXISTS key_values ("key" TEXT PRIMARY KEY, "value" TEXT, "date_created" TEXT);
